const c=Vue.defineComponent({name:"Welcome",__name:"index",setup(e){return(n,t)=>(Vue.openBlock(),Vue.createElementBlock("h1",null,"Pure-Admin-Thin（非国际化版本）"))}});export{c as default};
